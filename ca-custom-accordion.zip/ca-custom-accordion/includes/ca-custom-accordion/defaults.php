<?php
return array(
	'link_items' => '',
);