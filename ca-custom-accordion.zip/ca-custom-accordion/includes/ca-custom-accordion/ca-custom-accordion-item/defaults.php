<?php

/**
 * Element Defaults: Icon List Item
 */

return array(
	'id'           => '',
	'class'        => '',
	'style'        => '',
	'title'        => '',
    'sub_title'        => '',
    'right_text'        => '',
    'right_bottom_text'        => '',
	'content'         => '',
    'open'         => false,
);